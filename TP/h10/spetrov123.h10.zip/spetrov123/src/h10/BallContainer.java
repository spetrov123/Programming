package h10;
import java.util.ArrayList;

public class BallContainer {
	private ArrayList<Ball> ball = new ArrayList<Ball>();
	int nob = 10;
			
	public void add (Ball NewBall) {
		if (ball.size() != nob) {
			if(!ball.contains(NewBall)) {
				ball.add(NewBall);
			} else {
				System.out.println("The ball is already inside the container!!!");
			}
			
		} else {
			System.out.println("Container is full!!!");
		}
	}
	
	public void remove (Ball NewBall) {
		if (!ball.isEmpty()) {
			if (!ball.contains(NewBall)) {
				System.out.println("This ball is not in the container!!!");
			} else {
				ball.remove(NewBall);
			}
		} else {
			System.out.println("The container is empty!!!");
		}
	}
	
	public void clear() {
		ball.clear();
	}
	
	public int size() {
		System.out.println(ball.size());
		return ball.size();
	}
	
	public int getCapacity() {
		System.out.println(nob);
		return nob;
	}
	
	public boolean contains(Ball NewBall) {
		return ball.contains(NewBall);
	}
}	
