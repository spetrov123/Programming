package h10;

public class Ball {
	private String name;
	
	public String getName() {
		return name;
	}
	
	public void SetName(String name) {
		this.name = name;
	}
}
