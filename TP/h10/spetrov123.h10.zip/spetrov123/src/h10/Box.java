package h10;

public class Box {
	public static void main(String[] args) {
		Ball a = new Ball();
		Ball b = new Ball();
		Ball c = new Ball();
		BallContainer ball = new BallContainer();
		ball.add(a);
		ball.add(b);
		ball.add(c);
		ball.remove(c);
		ball.getCapacity();
		ball.size();
	}
}
